import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import {RouterModule,Routes} from '@angular/router';
import {HttpModule} from '@angular/http';
import {FormsModule} from '@angular/forms';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { CustomerLoginComponent } from './components/customer-login/customer-login.component';
import { HotelserviceService } from './hotelservice.service';
import { SearchHotelComponent } from './components/search-hotel/search-hotel.component';
import { HotelDetailsComponent } from './components/hotel-details/hotel-details.component';
import { BookingDetailsComponent } from './components/booking-details/booking-details.component';
import { RoomdetailsComponent } from './components/roomdetails/roomdetails.component';



const appRoutes:Routes=[
  {path: '',redirectTo: '/login',pathMatch: 'full'},
  {path:'login',component:CustomerLoginComponent},
  {path:'search',component:SearchHotelComponent},
  {path:'customerSearch',component:HotelDetailsComponent},
  {path:'bookingdetails',component:BookingDetailsComponent},
  {path:'roomdetails',component:RoomdetailsComponent}
]
@NgModule({
  declarations: [
    AppComponent,
    CustomerLoginComponent,
    SearchHotelComponent,
    HotelDetailsComponent,
    BookingDetailsComponent,
    RoomdetailsComponent
  ],
  imports: [
    BrowserModule,
    HttpModule,
    FormsModule,
    RouterModule.forRoot(appRoutes),
    AppRoutingModule
  ],
  providers: [HotelserviceService],
  bootstrap: [AppComponent]
})
export class AppModule { }
