import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import {RouterModule,Routes} from '@angular/router';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { RoomDetailsComponent } from './components/room-details/room-details.component';
import {HttpModule} from '@angular/http';
import { NewRoomdetailsComponent } from './Components/new-roomdetails/new-roomdetails.component';
import {FormsModule} from '@angular/forms';
import { RoomDetailsServiceService } from './room-details-service.service';
import { CancelBookingComponent } from './components/cancel-booking/cancel-booking.component';
import { CancelBookingFormComponent } from './components/cancel-booking-form/cancel-booking-form.component';
import { EditRoomDetailsComponent } from './components/edit-room-details/edit-room-details.component';
import { AdminComponent } from './components/admin/admin.component';
import { HoteldetailsComponent } from './components/hoteldetails/hoteldetails.component';
import { EdithotelComponent } from './components/edithotel/edithotel.component';
import { FormComponent } from './components/form/form.component';
import { AdminhomeComponent } from './components/adminhome/adminhome.component';
import { MainHomeComponent } from './components/main-home/main-home.component';

const appRoutes:Routes=[
  {path:'main',component:MainHomeComponent},
    {path:'',component:AdminComponent},
    {path:'adminhome',component:AdminhomeComponent},
    {path:'room',component:RoomDetailsComponent},
    {path:'edit',component:EditRoomDetailsComponent},
{path:'edith',component:EdithotelComponent},
    {path:'op',component:NewRoomdetailsComponent},
    {path:'hotel',component:HoteldetailsComponent},
    {path:'newhotel', component:FormComponent} ,
    {path:'cancel',component:CancelBookingComponent },
    {path:'cancelform',component:CancelBookingFormComponent}
]

@NgModule({
  declarations: [
    AppComponent,
    RoomDetailsComponent,
    NewRoomdetailsComponent,
    CancelBookingComponent,
    CancelBookingFormComponent,
    EditRoomDetailsComponent,
    AdminComponent,
    HoteldetailsComponent,
    EdithotelComponent,
    FormComponent,
    AdminhomeComponent,
    MainHomeComponent
    
  ],
  imports: [
    BrowserModule,
    HttpModule,
    FormsModule,
    RouterModule.forRoot(appRoutes),
    AppRoutingModule
  ],
  providers: [RoomDetailsServiceService],
  bootstrap: [AppComponent]
})
export class AppModule { }
