import { BookingDetails } from './booking-details';

describe('BookingDetails', () => {
  it('should create an instance', () => {
    expect(new BookingDetails()).toBeTruthy();
  });
});
