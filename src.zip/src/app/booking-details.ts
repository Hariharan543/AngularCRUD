export class BookingDetails {

    roomno:Number;
    userid:Number;
    fromdate:string;
    todate:string;
    price:Number;
    noofrooms:Number;
}
