export class Adminlogin {

    username:String;
    password:String;

}
