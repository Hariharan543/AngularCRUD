import { Customerdata } from './customerdata';

describe('Customerdata', () => {
  it('should create an instance', () => {
    expect(new Customerdata()).toBeTruthy();
  });
});
