import { Customerroomdetails } from './customerroomdetails';

describe('Customerroomdetails', () => {
  it('should create an instance', () => {
    expect(new Customerroomdetails()).toBeTruthy();
  });
});
