export class Customerroomdetails {
    hotel_id:number;
    roomno:number;
    roomtype:string;
    availability:string;
    price:number;
}
