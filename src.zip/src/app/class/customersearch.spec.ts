import { Customersearch } from './customersearch';

describe('Customersearch', () => {
  it('should create an instance', () => {
    expect(new Customersearch()).toBeTruthy();
  });
});
