import { Hoteldetails } from './hoteldetails';

describe('Hoteldetails', () => {
  it('should create an instance', () => {
    expect(new Hoteldetails()).toBeTruthy();
  });
});
