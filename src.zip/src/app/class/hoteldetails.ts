export class Hoteldetails {
    hotelid:number;
    hotelname:String;
    contactNumber:number;
    address:String;
    city:String;
    state:String;
    pincode:number;
    landmark:String;
    amenities:String;
    totalnoofrooms:number;

}
