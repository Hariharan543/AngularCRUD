import { SearchResults } from './search-results';

describe('SearchResults', () => {
  it('should create an instance', () => {
    expect(new SearchResults()).toBeTruthy();
  });
});
