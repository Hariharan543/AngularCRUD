import { Component, OnInit } from '@angular/core';
import { RoomDetailsServiceService } from 'src/app/room-details-service.service';
import { Adminlogin } from 'src/app/class/adminlogin';
import { Router } from '@angular/router';

@Component({
  selector: 'app-admin',
  templateUrl: './admin.component.html',
  styleUrls: ['./admin.component.css']
})
export class AdminComponent implements OnInit {
  private adminlogin:Adminlogin;
  constructor(private adminservice:RoomDetailsServiceService,private router:Router) { }

  ngOnInit() {
    
    this.adminlogin=new Adminlogin();

  }
  AdminLogin(adminlogin)
  {
    //Call Service..
    this.adminservice.validateAdminLogin(adminlogin).subscribe((data)=>{
      console.log(data); 
      if(data)
      {
        alert("Welcome      "+adminlogin.username);
        this.router.navigate(['/hoteldetails']);
      }
      else{
        alert("Invalid Data");
        this.router.navigate(['/adminhome']);

      }
    },(error)=>{
      console.log(error);
    })
  }
}
