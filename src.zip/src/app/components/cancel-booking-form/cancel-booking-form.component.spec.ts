import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { CancelBookingFormComponent } from './cancel-booking-form.component';

describe('CancelBookingFormComponent', () => {
  let component: CancelBookingFormComponent;
  let fixture: ComponentFixture<CancelBookingFormComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ CancelBookingFormComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CancelBookingFormComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
