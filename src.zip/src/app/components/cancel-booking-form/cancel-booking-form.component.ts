import { Component, OnInit } from '@angular/core';
import {Router} from '@angular/router';
import { RoomDetailsServiceService } from 'src/app/room-details-service.service';
import { BookingDetails } from 'src/app/booking-details';

@Component({
  selector: 'app-cancel-booking-form',
  templateUrl: './cancel-booking-form.component.html',
  styleUrls: ['./cancel-booking-form.component.css']
})
export class CancelBookingFormComponent implements OnInit {
private bookingdetails:BookingDetails[];
private bookingData:BookingDetails;
  constructor(private _userService:RoomDetailsServiceService, private _router:Router) { }

  ngOnInit() {
    this._userService.getBookingDetails().subscribe((bookingdetails)=>{
      console.log(bookingdetails); 
      this.bookingdetails=this.bookingdetails;
    },(error)=>{
      console.log(error);
    })

  }

  
  
  cancelRoomBooking(){    
   //  bookingdetailss:new BookingDetails();
    this.bookingData=this._userService.getterbookingdetail();
    this._userService.cancelRoomBooking(Number(localStorage.getItem("roomNo"))).subscribe((roomdetails)=>{    
      this._router.navigate(['/cancel']);

      this.bookingdetails.splice(this.bookingdetails.indexOf(roomdetails),1);
    //  this._router.navigate(['/cancel']);
      alert("ok")
      
    },(error)=>{
      console.log(error);
    });

  }
}
