import { Component, OnInit } from '@angular/core';
import {Router} from '@angular/router';
import {BookingDetails} from 'src/app/booking-details'

import { RoomDetailsServiceService } from 'src/app/room-details-service.service';

@Component({
  selector: 'app-cancel-booking',
  templateUrl: './cancel-booking.component.html',
  styleUrls: ['./cancel-booking.component.css']
})
export class CancelBookingComponent implements OnInit {
private bookingdetails:BookingDetails[];

  constructor(private _userService:RoomDetailsServiceService,private router:Router) { }

  ngOnInit() {
    this._userService.getBookingDetails().subscribe((bookingdetails)=>{
      console.log(bookingdetails); 
      this.bookingdetails=bookingdetails;
    },(error)=>{
      console.log(error);
    })
      
    
    
  }
  cancelbooking(bookingdetails){
    localStorage.setItem('roomNo', bookingdetails.roomno);
    //alert(localStorage.getItem('roomNo'));
    this._userService.setterbookingdetail(bookingdetails);
    this.router.navigate(['/cancelform']);


  }
}
