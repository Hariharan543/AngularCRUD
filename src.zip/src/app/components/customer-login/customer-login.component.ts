import { Component, OnInit } from '@angular/core';
import {HotelserviceService} from 'src/app/hotelservice.service';
import {Router} from '@angular/router';
import { CustomerData } from 'src/app/customer-data';

@Component({
  selector: 'app-customer-login',
  templateUrl: './customer-login.component.html',
  styleUrls: ['./customer-login.component.css']
})
export class CustomerLoginComponent implements OnInit {
private customerdata1=new CustomerData();
  constructor(private _hotelservice:HotelserviceService,private _router:Router) { }

  ngOnInit() {
  }
logincustomer()
    {
      this._hotelservice.validateCustomer(this.customerdata1).subscribe((data)=>
      {
        console.log(data);
        if(data)
        {
                alert('Welcome '+this.customerdata1.name);
                this._router.navigate(['/search']);
           }
            else{
                alert('InvalidCredential'); 
           }
      },(error)=>{
        console.log(error);
      }
      );
 }}