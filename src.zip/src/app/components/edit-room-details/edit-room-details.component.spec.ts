import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { EditRoomDetailsComponent } from './edit-room-details.component';

describe('EditRoomDetailsComponent', () => {
  let component: EditRoomDetailsComponent;
  let fixture: ComponentFixture<EditRoomDetailsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ EditRoomDetailsComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(EditRoomDetailsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
