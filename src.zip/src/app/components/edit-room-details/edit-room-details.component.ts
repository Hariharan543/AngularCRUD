import { Component, OnInit } from '@angular/core';
import {Router} from '@angular/router';
import { RoomDetailsServiceService } from 'src/app/room-details-service.service';
import {Roomdetails} from 'src/app/roomdetails';

@Component({
  selector: 'app-edit-room-details',
  templateUrl: './edit-room-details.component.html',
  styleUrls: ['./edit-room-details.component.css']
})
export class EditRoomDetailsComponent implements OnInit {

  private roomdetails=new Roomdetails();

  constructor(private _userService:RoomDetailsServiceService, private _router:Router) { }

  ngOnInit() {
    this.roomdetails=this._userService.getter();
   // alert(this.roomdetails.roomno)
  }
  
  //   this._userService.createNewRoomDetails(this.roomdetails).subscribe((user)=> {
  //     console.log(user);
  //     this._router.navigate(['/']);
  //   }, (error)=>{
  //     console.log(error);
  //   });}
  //  

      // else{

processForm()
        {
      
         this._userService.updateNewRoomDetails(this.roomdetails).subscribe((user)=>{
          console.log(user);
           this._router.navigate(['/room']);
         },(error)=>{
          console.log(error);
         });

       }
 

  }

