import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Hoteldetails } from 'src/app/class/Hoteldetails';
import { RoomDetailsServiceService } from 'src/app/room-details-service.service';

@Component({
  selector: 'app-edithotel',
  templateUrl: './edithotel.component.html',
  styleUrls: ['./edithotel.component.css']
})
export class EdithotelComponent implements OnInit {
  private hotelDetails:Hoteldetails;

  constructor(private service:RoomDetailsServiceService,private router:Router) { }

  ngOnInit() {
    this.hotelDetails=this.service.gettersHotelDetails();
    
  }
editHotel(hotelDetails)
{

  this.service.editHotel(hotelDetails).subscribe((data)=>{
   // alert(hoteldetails.hotelid);
  console.log(data);
  this.router.navigate(['/hotel']);
  },
  (error)=>{console.log(error);}
  )
}
}


