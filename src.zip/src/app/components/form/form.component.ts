import { Component, OnInit } from '@angular/core';

import { Hoteldetails } from 'src/app/class/hoteldetails';
import { RoomDetailsServiceService } from 'src/app/room-details-service.service';
import { Router } from '@angular/router';
@Component({
  selector: 'app-form',
  templateUrl: './form.component.html',
  styleUrls: ['./form.component.css']
})
export class FormComponent implements OnInit {

  private hoteldetails=new Hoteldetails();
  constructor(private service:RoomDetailsServiceService,private router:Router) { }

  ngOnInit() 
  {
    this.hoteldetails=this.service.gettersHotelDetails();
    //this.hoteldetails=this.service.get();

  }
  processForm()
{
  this.service.addHotel(this.hoteldetails).subscribe((user)=> {
    console.log(user);
    this.router.navigate(['/hotel']);
  }, (error)=>{
    console.log(error);
  });}

}

