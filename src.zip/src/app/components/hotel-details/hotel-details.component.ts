import { Component, OnInit } from '@angular/core';
import {HotelserviceService} from 'src/app/hotelservice.service';
import {Router} from '@angular/router'; 
import { HotelDetails } from 'src/app/hotel-details';
import { Roomdetails } from 'src/app/roomdetails';


@Component({
  selector: 'app-hotel-details',
  templateUrl: './hotel-details.component.html',
  styleUrls: ['./hotel-details.component.css']
})
export class HotelDetailsComponent implements OnInit {
  private hoteldetails:HotelDetails[];
  private hotel=new HotelDetails();
  private roomdetails:Roomdetails[];

  constructor(private _hotelservice:HotelserviceService,private _router:Router) { }

  ngOnInit() {
    this._hotelservice.getterSearch();
    this.hoteldetails=this._hotelservice.getter();
    console.log("IN HOTEL");
    console.log(this.hoteldetails);
    console.log(this.hoteldetails.length);
    console.log(JSON.stringify(this.hoteldetails));
  }

  room(i){
    this._hotelservice.roomdetail(i).subscribe((data)=>{
      console.log(data); 
      this.roomdetails=data;
      console.log("MORE..");
       console.log(this.roomdetails);
       this._hotelservice.setterRoomDetails(this.roomdetails);
       this._router.navigate(['/roomdetails']);
    },(error)=>{
      console.log(error);
    })      
}

backsearch(){
      this._router.navigate(['/search']);
}
}
