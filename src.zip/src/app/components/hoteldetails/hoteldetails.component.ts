import { Component, OnInit } from '@angular/core';
import { Hoteldetails } from 'src/app/class/hoteldetails';
import { RoomDetailsServiceService } from 'src/app/room-details-service.service';
import { Router } from '@angular/router';
import { Roomdetails } from 'src/app/roomdetails';

@Component({
  selector: 'app-hoteldetails',
  templateUrl: './hoteldetails.component.html',
  styleUrls: ['./hoteldetails.component.css']
})
export class HoteldetailsComponent implements OnInit {
private hoteldetails:Hoteldetails[];
private roomdetails:Roomdetails[];
  constructor(private adminservice:RoomDetailsServiceService,private router:Router) { }

  ngOnInit()
   {
this.adminservice.hotelList().subscribe((data)=>{console.log(data); 
this.hoteldetails=data;
},(error)=>{
console.log(error);
})
  }
  deleteHotel(detail)
  {
    this.adminservice.deleteHotel(detail.hotelid).subscribe((data)=>{
      this.hoteldetails.splice(this.hoteldetails.indexOf(detail),1);
    },(error)=>{
      console.log(error);
    });
  }
  updateHotel(detail)
  {
    alert(detail.hotelid);
    this.adminservice.settersHotelDetails(detail);
    this.router.navigate(['/edith']);
 }
 newHotel()
 {
   let hoteldetails=new Hoteldetails();
   this.adminservice.settersHotelDetails(hoteldetails);
   this.router.navigate(['/newhotel']);
 }

Roomdetails(){
this.router.navigate(['/room']);

}

}
