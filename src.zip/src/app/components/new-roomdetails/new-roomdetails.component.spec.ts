import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { NewRoomdetailsComponent } from './new-roomdetails.component';

describe('NewRoomdetailsComponent', () => {
  let component: NewRoomdetailsComponent;
  let fixture: ComponentFixture<NewRoomdetailsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ NewRoomdetailsComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(NewRoomdetailsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
