import { Component, OnInit } from '@angular/core';
import {Router} from '@angular/router';
import { RoomDetailsServiceService } from 'src/app/room-details-service.service';
import {Roomdetails} from 'src/app/roomdetails';
@Component({
  selector: 'app-new-roomdetails',
  templateUrl: './new-roomdetails.component.html',
  styleUrls: ['./new-roomdetails.component.css']
})
export class NewRoomdetailsComponent implements OnInit {
private roomdetails=new Roomdetails();

  constructor(private _userService:RoomDetailsServiceService, private _router:Router) { }

  ngOnInit() {
    this.roomdetails=this._userService.getter();
   // alert(this.roomdetails.roomno)
  }
  processForm()
  {

    this._userService.createNewRoomDetails(this.roomdetails).subscribe((user)=> {
      console.log(user);
      this._router.navigate(['/room']);
    }, (error)=>{
      console.log(error);
    });}
   /*if(this.roomdetails.roomno==undefined){
    this._userService.createNewRoomDetails(this.roomdetails).subscribe((user)=> {
        console.log(user);
        this._router.navigate(['/']);
      }, (error)=>{
        console.log(error);
      });
    }
*/
      // else{
      //   this._userService.updateNewRoomDetails(this.roomdetails).subscribe((user)=>{
      //     console.log(user);
      //     this._router.navigate(['/']);
      //   },(error)=>{
      //     console.log(error);
      //   });
  
      // }
 

  }

