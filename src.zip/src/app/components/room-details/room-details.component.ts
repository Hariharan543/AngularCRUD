import { Component, OnInit } from '@angular/core';
import {Router} from '@angular/router';
import { Roomdetails } from 'src/app/roomdetails';
import { RoomDetailsServiceService } from 'src/app/room-details-service.service';


@Component({
  selector: 'app-room-details',
  templateUrl: './room-details.component.html',
  styleUrls: ['./room-details.component.css']
})
export class RoomDetailsComponent implements OnInit {
private roomdetails:Roomdetails[];
  constructor(private _userService:RoomDetailsServiceService, private _router:Router) { }

  ngOnInit() {
    this._userService.getRoomList().subscribe((roomdetails)=>{
      console.log(roomdetails); 
      this.roomdetails=roomdetails;
    },(error)=>{
      console.log(error);
    })
  }
  
  deleteRoomByNo(roomdetails){
    alert("ok")
    this._userService.deleteRoomByNo(roomdetails.roomno).subscribe((roomdetails)=>{
      this.roomdetails.splice(this.roomdetails.indexOf(roomdetails),1);
    },(error)=>{
      console.log(error);
    });
  }

  updateNewRoomDetails(roomdetails){
    //alert(roomdetails.roomno);
     this._userService.setter(roomdetails);
     this._router.navigate(['/edit']);
  }
   
  createNewRoomDetails(){
    let roomdetails= new Roomdetails();
    this._userService.setter(roomdetails);

    this._router.navigate(['/op']);

  }
}
    


