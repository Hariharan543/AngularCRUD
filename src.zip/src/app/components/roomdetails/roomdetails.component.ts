import { Component, OnInit } from '@angular/core';
import { Roomdetails } from 'src/app/roomdetails';
import {HotelserviceService} from 'src/app/hotelservice.service';
import {Router} from '@angular/router'; 


@Component({
  selector: 'app-roomdetails',
  templateUrl: './roomdetails.component.html',
  styleUrls: ['./roomdetails.component.css']
})
export class RoomdetailsComponent implements OnInit {
  private roomdetails:Roomdetails[];
  constructor(private _hotelservice:HotelserviceService,private _router:Router) { }

  ngOnInit() {
    this._hotelservice.getterRoomDetails();
    this.roomdetails=this._hotelservice.getterRoomDetails();
    console.log("IN HOTEL");
    console.log(this.roomdetails);
    console.log(this.roomdetails.length);
    console.log(JSON.stringify(this.roomdetails));
  }
  bookhotel(){
    this._router.navigate(['/bookingdetails']);

  }
  backsearch(){
    this._router.navigate(['/customerSearch']);
}
}
