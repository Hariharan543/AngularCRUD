import { Component, OnInit } from '@angular/core';
import {HotelserviceService} from 'src/app/hotelservice.service';
import {Router} from '@angular/router'; 
import { Customersearch } from 'src/app/customersearch';
import { HotelDetails } from 'src/app/hotel-details';



@Component({
  selector: 'app-search-hotel', 
  templateUrl: './search-hotel.component.html',
  styleUrls: ['./search-hotel.component.css']
})
export class SearchHotelComponent implements OnInit {
  private customersearch=new Customersearch();
private hoteldetails:HotelDetails[];

  constructor(private _hotelservice:HotelserviceService,private _router:Router) { }
  ngOnInit() {

  }
  
  processForm(customersearch){
    alert(this.customersearch.city);
    this._hotelservice.searchHotel(customersearch).subscribe((data)=>{
      console.log(data); 
      this.hoteldetails=data;
      console.log("MORE..");
       console.log(this.hoteldetails);
       this._hotelservice.setterResult(this.hoteldetails);
       this._router.navigate(['/customerSearch']);
    },(error)=>{
      console.log(error);
    })      
}
}
