import { CustomerData } from './customer-data';

describe('CustomerData', () => {
  it('should create an instance', () => {
    expect(new CustomerData()).toBeTruthy();
  });
});
