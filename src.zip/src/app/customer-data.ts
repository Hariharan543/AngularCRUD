export class CustomerData {
    userid:number;
    name:string;
    password:string;
    email:string;
    mobile:number;
    address:string;
    city:string;
    state:string;
    pincode:number;
}
