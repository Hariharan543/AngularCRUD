export class Customersearch {
    userid:number;
    from_date:string;
    to_date:string;
    city:string;
    no_of_rooms:number;
    roomtype:string;
    no_of_adults:number;
    no_of_childs:number;
}
