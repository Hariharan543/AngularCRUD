import { HotelDetails } from './hotel-details';

describe('HotelDetails', () => {
  it('should create an instance', () => {
    expect(new HotelDetails()).toBeTruthy();
  });
});
