export class HotelDetails {
    hotelid:number;
    hotelname:string;
    ContactNumber:number;
    address:string;
    city:string;
    state:string;
    pincode:number;
    landmark:string;
    amenities:string;
    totalnoofrooms:number;
}
