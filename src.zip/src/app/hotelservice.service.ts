import { Injectable } from '@angular/core';
import {Http,Response,RequestOptions,Headers} from '@angular/http';
import {Observable} from 'rxjs/Observable';
import 'rxjs/add/operator/map';
import 'rxjs/add/operator/catch';
import 'rxjs/add/observable/throw';
import { Customersearch } from './customersearch';
import { HotelDetails } from './hotel-details';
import { Roomdetails } from './roomdetails';


@Injectable({
  providedIn: 'root'
})
export class HotelserviceService 
{
private baseurl="http://localhost:3004/hotel";
private headers=new Headers({'content-Type':'Application/JSON'});
private options=new RequestOptions({headers:this.headers});
private customersearch:Customersearch;
private roomdetails:Roomdetails[];
private hoteldetails:HotelDetails[];

  constructor(private _http:Http) { }

  validateCustomer(customerdata){
    return this._http.post(this.baseurl+'/validateLogin',customerdata,this.options).map((response:Response)=>response.json()).catch(this.errorHandler);
  }

  getHotel(){
    return this._http.post(this.baseurl+'/customerSearch',this.options).map((response:Response)=>response.json())
      .catch(this.errorHandler);
  }

  searchHotel(customerSearch){
    return this._http.post(this.baseurl+'/customerSearch',customerSearch,this.options).map((response:Response)=>response.json()).catch(this.errorHandler);
  }

  roomdetail(hoteldetails){
    return this._http.post(this.baseurl+'/viewRooms',hoteldetails,this.options).map((response:Response)=>response.json()).catch(this.errorHandler);

  }


  errorHandler(error:Response){
    return Observable.throw(error ||"SERVER ERROR");
  }
  
  setterSearch(customersearch:Customersearch){
    this.customersearch=customersearch;
  }
  getterSearch(){
    return this.customersearch;
  }

  setterResult(hoteldetails:HotelDetails[]){
    this.hoteldetails=hoteldetails;
  }

  getter(){
    return this.hoteldetails;
  }

  setterRoomDetails(roomdetails:Roomdetails[]){
    this.roomdetails=roomdetails;
  }

  getterRoomDetails(){
    return this.roomdetails;
  }
}
