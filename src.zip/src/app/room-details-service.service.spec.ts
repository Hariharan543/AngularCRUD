import { TestBed } from '@angular/core/testing';

import { RoomDetailsServiceService } from './room-details-service.service';

describe('RoomDetailsServiceService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: RoomDetailsServiceService = TestBed.get(RoomDetailsServiceService);
    expect(service).toBeTruthy();
  });
});
