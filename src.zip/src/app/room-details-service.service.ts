import { Injectable } from '@angular/core';
import {Http, Response, Headers, RequestOptions} from '@angular/http';
import {Observable} from 'rxjs/Observable';
import 'rxjs/add/operator/map';
import 'rxjs/add/operator/catch';
import 'rxjs/add/Observable/throw';
import { Roomdetails } from './roomdetails';
import { BookingDetails } from './booking-details';
import { Hoteldetails } from './class/hoteldetails';
import { Adminlogin } from './class/adminlogin';

@Injectable({
  providedIn: 'root'
})
export class RoomDetailsServiceService {
  private baseUrl:string='http://localhost:3300/hotel';
  private headers= new Headers({'Content-Type':'application/json'});
  private options = new RequestOptions({headers:this.headers});
  private roomdetails:Roomdetails;
  private adminlogin:Adminlogin;
  private hoteldetails:Hoteldetails;
  private bookingdetails:BookingDetails;
  constructor(private _http:Http) { }
  

  
  validateAdminLogin(adminlogin)
  {
    return this._http.post(this.baseUrl+'/validateAdminLogin',JSON.stringify(adminlogin),this.options)
    .map((response:Response)=>response.json()).catch(this.errorHandler);
  }
  
  hotelList()
  {
    return this._http.get(this.baseUrl+'/hotelList',this.options).map((response:Response)=>response.json())
    .catch(this.errorHandler);
  }
  addHotel(hoteldetails:Hoteldetails)
  {
    return this._http.post(this.baseUrl+'/addHotel',JSON.stringify(hoteldetails), this.options).map((response:Response)=>response.json())
    .catch(this.errorHandler);
  }
  editHotel(hotel:Hoteldetails)
  {
    return this._http.put(this.baseUrl+'/editHotel',JSON.stringify(hotel), this.options).map((response:Response)=>response.json())
    .catch(this.errorHandler);
  }
  deleteHotel(hotelid:number)
  {
    return this._http.delete(this.baseUrl+'/deleteHotel/'+hotelid,this.options).map((response:Response)=>response.json())
    .catch(this.errorHandler);
  }
  errorHandlerForHotelDetails(error:Response)
  {
    return Observable.throw(error||"Server Error");
  }
  getterAdminLogin()
  {
    return this.adminlogin;
  }
  setterAdminLogin(adminlogin:Adminlogin)
  {
    this.adminlogin=adminlogin;
  }
  gettersHotelDetails()
  {
   //this.hoteldetails=new Hoteldetails();
    return this.hoteldetails;
  }
  settersHotelDetails(hoteldetails:Hoteldetails)
  {
     this.hoteldetails=hoteldetails;
  }
  
  

  getRoomList(){
    this.roomdetails=new Roomdetails();
    return this._http.get(this.baseUrl+'/listRoom',this.options).map((response:Response)=>response.json())
      .catch(this.errorHandler);
  }


  getRoomByRoomNo(roomno:Number){
    return this._http.get(this.baseUrl+'/listRoom/'+roomno, this.options).map((response:Response)=>response.json())
      .catch(this.errorHandler);
  }

  deleteRoomByNo(roomno:Number){
    alert("okkkkkkk")

    return this._http.delete(this.baseUrl+'/deleteRoom/'+roomno,this.options).map((response:Response)=>response.json())
      .catch(this.errorHandler);
  }

  createNewRoomDetails(roomdetails:Roomdetails){
    //alert(roomdetails.availabity);
    return this._http.post(this.baseUrl+'/saveRoom',JSON.stringify(roomdetails), this.options).map((response:Response)=>response.json())
      .catch(this.errorHandler);
  }

  updateNewRoomDetails(roomdetails:Roomdetails){
    return this._http.put(this.baseUrl+'/editRoom',JSON.stringify(roomdetails), this.options).map((response:Response)=>response.json())
      .catch(this.errorHandler);
  }

getBookingDetails(){
   this.bookingdetails= new BookingDetails();
   return this._http.get(this.baseUrl+'/listbookingdetails',this.options).map((response:Response)=>response.json())
   .catch(this.errorHandler);


}

cancelRoomBooking(roomno:Number){
  return this._http.delete(this.baseUrl+'/customerCancelationRoom/'+roomno,this.options).map((response:Response)=>response.json())
  .catch(this.errorHandler);

}

errorHandler(error:Response){
  return Observable.throw(error || "SERVER ERROR");
}

setter(roomdetails:Roomdetails){
  this.roomdetails=roomdetails;
}



getter(){
  return this.roomdetails;  
}


getterbookingdetail(){
  return this.bookingdetails;  
}
setterbookingdetail(bookingdetails:BookingDetails){
  this.bookingdetails=bookingdetails;
}
}
