import { Roomdetails } from './roomdetails';

describe('Roomdetails', () => {
  it('should create an instance', () => {
    expect(new Roomdetails()).toBeTruthy();
  });
});
