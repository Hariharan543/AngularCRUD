export class Roomdetails {
    hotelid:Number;
    roomno:Number;
    roomtype:string;
    availabity:string;
    price:Number;

}
