export class Roomdetails {
    hotel_id:number;
    roomno:number;
    roomtype:string;
    availability:string;
    price:number;
}
